package Vehicle;

public abstract class Vehicle {
    protected String name;
    protected int age;
    protected String carComfort;

    public Vehicle(String name, int age, String carComfort) {
        this.name = name;
        this.age = age;
        this.carComfort = carComfort;
    }

    // Abstract method to display information
    public abstract void displayInfo();
}
