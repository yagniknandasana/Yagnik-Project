import drivers.*;
import java.io.*;
// import java.io.BufferedReader;
// import java.io.BufferedWriter;
// import java.io.FileReader;
// import java.io.FileWriter;
// import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class OnlineCabBooking {
    public static void main(String[] args) {
        Driver[] drivers = loadDrivers();
        loadRouteDetails(drivers);

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            try{
            System.out.println("Menu:");
            System.out.println("1. Cab Booking");
            System.out.println("2. Driver Profiles");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    bookCab(scanner, drivers);
                    break;
                case 2:
                    displayDriverProfiles(drivers);
                    break;
                case 3:
                    System.out.println("Exiting the system. Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            }catch(InputMismatchException e){
                System.out.println("Please enter Valid Integer choice");
                scanner.nextLine();
                choice = -1;
            }
        } while (choice != 3);

        scanner.close();
    }

    private static Driver[] loadDrivers() {
        Driver[] drivers = new Driver[3];
        try (BufferedReader br = new BufferedReader(new FileReader("DriverDetails.txt"))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null && i < drivers.length) {
                String[] data = line.split(",");
                drivers[i] = new Driver(data[0], Integer.parseInt(data[1]), Integer.parseInt(data[2]),
                        Double.parseDouble(data[3]), data[4], data[5]);
                i++;
            }
        } catch (IOException e) {
            System.out.println("Error reading driver details file.");
        }
        return drivers;
    }

    private static void loadRouteDetails(Driver[] drivers) {
        for (int i = 0; i < drivers.length; i++) {
            String filename = "D" + (i + 1) + "_RoutePriceAndTime.txt";
            try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] data = line.split(",");
                    int from = Integer.parseInt(data[0]);
                    int to = Integer.parseInt(data[1]);
                    double price = Double.parseDouble(data[2]);
                    int time = Integer.parseInt(data[3]);
                    drivers[i].setPriceAndTime(from, to, price, time);
                }
            } catch (IOException e) {
                System.out.println("Error reading file " + filename);
            }
        }
    }

    private static void bookCab(Scanner scanner, Driver[] drivers) {
        System.out.println("Enter your current location (Ahmedabad, Surat, Jamnagar, Rajkot, Himmatnagar):");
        String currentLocation = scanner.next();
        System.out.println("Enter your destination (Ahmedabad, Surat, Jamnagar, Rajkot, Himmatnagar):");
        String destination = scanner.next();
        

        // Convert locations to indices
        int from = getLocationIndex(currentLocation);
        int to = getLocationIndex(destination);

        if (from == -1 || to == -1 || (from == to)) {
            System.out.println("Invalid location. Please try again.");
            return;
        }

        Driver selectedDriver = null;
        double bestPrice = 10000;
        int bestTime = 10000;
        boolean valid = false;

        System.out.println("Enter your priority (time/price/comfort):");
        String priority = scanner.next();

        while (!valid) {            
            if (priority.equalsIgnoreCase("time")) {
                for (Driver driver : drivers) {
                    int time = driver.getTime(from, to);
                    if (time < bestTime) {
                        bestTime = time;
                        selectedDriver = driver;
                    }
                }
                valid = true;
            } else if (priority.equalsIgnoreCase("price")) {
                for (Driver driver : drivers) {
                    double price = driver.getPrice(from, to);
                    if (price < bestPrice) {
                        bestPrice = price;
                        selectedDriver = driver;
                    }
                }
                valid = true;
            } else if (priority.equalsIgnoreCase("comfort")) {
                boolean flag = false;
                
                while (!flag) {
                try{
                    System.out.println("Enter 1 for Medium Comfort Car | 2 for Good Comfort Car | 3 for Premium Comfort Car");
                    int comfortChoice = scanner.nextInt();
                    if (comfortChoice == 1) {
                        selectedDriver = drivers[2]; // Medium comfort
                        flag = true;
                    } else if (comfortChoice == 2) {
                        selectedDriver = drivers[1]; // Good comfort
                        flag = true;
                    } else if (comfortChoice == 3) {
                        selectedDriver = drivers[0]; // Premium comfort
                        flag = true;
                    } else {
                        System.out.println("Please Enter Appropriate Comfort Choice");
                    }
                }
                catch(InputMismatchException e){
                    System.out.println("Please enter Valid Integer choice");
                    scanner.nextLine();
                }
            }
            
                valid = true;
            } else {
                System.out.println("Please Enter Appropriate Priority");
                priority = scanner.next();
            }
        }

        if (selectedDriver != null) {
            System.out.println();
            System.out.println("Best driver According to Your Priority:");
            System.out.println("Driver Name: " + selectedDriver.getName());
            System.out.println("Estimated Time: " + selectedDriver.getTime(from, to) + " minutes");
            System.out.println("Price: " + selectedDriver.getPrice(from, to));

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("BookingLog.txt", true))) {
            writer.write("Booking Details:\n");
            writer.write("Driver Name: " + selectedDriver.getName() + "\n");
            writer.write("From: " + currentLocation + " To: " + destination + "\n");
            writer.write("Priority: " + priority + "\n");
            writer.write("Estimated Time: " + selectedDriver.getTime(from, to) + " minutes\n");
            writer.write("Price: " + selectedDriver.getPrice(from, to) + "\n");
            writer.write("--------------------------------------------------\n");
            writer.flush();
            System.out.println("Booking details have been logged.");
            System.out.println();
        } catch (IOException e) {
            System.out.println("An error occurred while logging booking details.");
        }
            
        } else {
            System.out.println("No available drivers for this route.");
        }
    }

    private static void displayDriverProfiles(Driver[] drivers) {
        for (Driver driver : drivers) {
            driver.displayInfo();
        }
    }

    private static int getLocationIndex(String location) {
        switch (location.toLowerCase()) {
            case "jamnagar":
                return 0;
            case "rajkot":
                return 1;
            case "ahmedabad":
                return 2;
            case "surat":
                return 3;
            case "himmatnagar":
                return 4;
            default:
                return -1; // Invalid location
        }
    }
}