package service;
public interface RouteService {
    void setPriceAndTime(int from, int to, double price, int time);
    double getPrice(int from, int to);
    int getTime(int from, int to);
}
