package drivers;
import Vehicle.*;
import service.*;

public class Driver extends Vehicle implements RouteService {
    private int tripsDone;
    private double rating;
    private String feedback;

    // Route prices and times
    private double[][] routePrices = new double[5][5];
    private int[][] routeTimes = new int[5][5];

    // Constructor
    public Driver(String name, int age, int tripsDone, double rating, String feedback, String carComfort) {
        super(name, age, carComfort); // Call to parent (Vehicle) constructor
        this.tripsDone = tripsDone;
        this.rating = rating;
        this.feedback = feedback;
    }


    @Override
    public void setPriceAndTime(int from, int to, double price, int time) {
        double adjustedPrice = adjustment(price);
        int adjustedTime = adjustment(time);
        
        routePrices[from][to] = adjustedPrice;
        routePrices[to][from] = adjustedPrice;
        routeTimes[from][to] = adjustedTime;
        routeTimes[to][from] = adjustedTime;
    }
   
    // Method Overloading
    private double adjustment(double basePrice) {
        switch (carComfort.toLowerCase()) {
            case "premium": return basePrice * 1.5;
            case "good": return basePrice * 1.2;
            case "medium": return basePrice;
            default: return basePrice;
        }
    }

    private int adjustment(int baseTime) {
        switch (carComfort.toLowerCase()) {
            case "premium": return baseTime;
            case "good": return (int) (baseTime * 1.1);
            case "medium": return (int) (baseTime * 1.2);
            default: return baseTime;
        }
    }

    @Override
    public void displayInfo() {
        System.out.println();
        System.out.println("Driver Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Comfort: " + carComfort);
        System.out.println("Rating: " + rating + ", Feedback: " + feedback);
        System.out.println("Routes:");
        String[] places = {"Jamnagar", "Rajkot", "Ahmedabad", "Surat", "Himmatnagar"};
        for (int i = 0; i < 5; i++) {
            for (int j = i + 1; j < 5; j++) {
                if (routePrices[i][j] > 0) {
                    System.out.println(places[i] + " to " + places[j] + " - Price: " + routePrices[i][j] + ", Time: " + routeTimes[i][j] + " minutes");
                }
            }
        }
        System.out.println();
    }

    @Override
    public double getPrice(int from, int to) {
        return routePrices[from][to];
    }

    @Override
    public int getTime(int from, int to) {
        return routeTimes[from][to];
    }

    public String getName() {
        return name;
    }
}