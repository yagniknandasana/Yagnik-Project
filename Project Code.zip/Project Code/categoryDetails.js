var categorySelected = localStorage.getItem("categorySelected");
var categoryId = localStorage.getItem("categoryId");
var objCategory = [];

let regName = /^[ A-za-z]{2,100}$/;
let regEmail = /^[A-Za-z0-9]{3,100}@gmail\.com$/;
let regMobileNo = /^[0-9]{10}$/;

function displayCategories(categorySelected){
    if (categorySelected == "venues"){
        objCategory = venuesCategory.filter((venue) => venue.id == categoryId);
    } else if (categorySelected == "photographers"){
        objCategory = photographersCategory.filter((venue) => venue.id == categoryId);
    } else if (categorySelected == "planning"){
        objCategory = planningCategory.filter((venue) => venue.id == categoryId);
    } else if (categorySelected == "pre_wedding_shoot"){
        objCategory = pre_wedding_shootCategory.filter((venue) => venue.id == categoryId);
    }
}

function categoryBinding(objCategory){
    var strCategory = "";
    for(var i = 0; i < objCategory.length; i++) {
        strCategory += '<div><img src="'+objCategory[i]["image"]+'" alt="Venues" height="390" width="700"><div style="padding-left: 3%;padding-top: 1%;padding-bottom: 0.5%;background-color: white;border-color: red; width: 90%;margin-left: 3.5%;margin-top: -10%;z-index: 0;position: relative;box-shadow: 6px 10px 7px -2px;border: 1px solid;"><h2 style="color: rgb(173, 26, 26);">'+objCategory[i]["name"]+'</h2><p style="float: right;margin-right: 4%;margin-top: -8%;"><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star checked"></span><span class="fa fa-star"></span><span class="fa fa-star"></span> <span style="color:brown;">'+objCategory[i]["review"]+'</span></p><p style="color: rgb(0, 129, 86);">'+objCategory[i]["info1"]+'</p><p style="color: rgb(54, 0, 129);">'+objCategory[i]["info2"]+'</p></div></div>';
    }
    $("#categoryList").html(strCategory);
}

function orderBook(){
    let name = document.querySelector("#name");
    let email = document.querySelector("#email");
    let mobileNo = document.querySelector("#mobile");
    let date = document.querySelector("#date");

    let isValid = true; 
    let x = 0;

    if(regName.test(name.value)) {
        name.style.border="0px";
        name.style.borderBottom="2px solid hotpink";
        x++; 
    } else {
        isValid = false; 
        name.style.border="2px solid red";
    }

    if(regEmail.test(email.value)) {
        email.style.border="0px";
        email.style.borderBottom="2px solid hotpink";
        x++; 
    } else {
        isValid = false; 
        email.style.border="2px solid red";
    }

    if(regMobileNo.test(mobileNo.value)) {
        mobileNo.style.border="0px";
        mobileNo.style.borderBottom="2px solid hotpink";
        x++; 
    } else {
        isValid = false; 
        mobileNo.style.border="2px solid red";
    }
    console.log(date.value);
    if(date.value != "") {
        date.style.border="0px";
        date.style.borderBottom="2px solid hotpink";
        x++; 
    } else {
        isValid = false; 
        date.style.border="2px solid red";
    }

    if(x==4) {//isValid
        window.location.href="orderBooked.html";
    } else {
        return false;
    }
}

displayCategories(categorySelected);

categoryBinding(objCategory);   

