var categorySelected = localStorage.getItem("categorySelected");
var objCategory = [];

function displayCategories(categorySelected){
    if (categorySelected == "venues"){
        objCategory = venuesCategory;
        $("#title").text("Venues");
    } else if (categorySelected == "photographers"){
        objCategory = photographersCategory;
        $("#title").text("Photographers");
    } else if (categorySelected == "planning"){
        objCategory = planningCategory;
        $("#title").text("Planning & Decor");
        $("#search").css("margin-left","53%");
    } else if (categorySelected == "pre_wedding_shoot"){
        objCategory = pre_wedding_shootCategory;
        $("#title").text("Pre Wedding Shoot");
        $("#search").css("margin-left","52%");
    }
}

function categoryDetails(categoryId) {
    localStorage.setItem("categoryId", categoryId);
    window.location.href="categoryDetails.html";
}

function categoryBinding(objCategory){
    var strCategory = "";
    for(var i = 0; i < objCategory.length; i++) {
        strCategory += '<div class="card"><img src="'+objCategory[i]["image"]+'" alt="Venues" height="190"><h2>'+objCategory[i]["name"]+'</h2><p>'+objCategory[i]["info1"]+'</p><p>'+objCategory[i]["info2"]+'</p><button onclick="categoryDetails('+objCategory[i]["id"]+')">Book</button></div>';
    }
    $("#categoryList").html(strCategory);
}


function clearSearch(){
    $("#search").val('');
    search();
}

function search(){
    var strSearch = $("#search").val().toLowerCase();
    var matchingCategory = [];

    for(var i = 0; i < objCategory.length; i++) {
        if (objCategory[i].name.toLowerCase().includes(strSearch)) {
            matchingCategory.push(objCategory[i]);
        }
    }
    displayCategory(matchingCategory);
}

function displayCategory(matchingCategory) {
    var strCategory = "";
    for(var i = 0; i < matchingCategory.length; i++) {
        strCategory += '<div class="card"><img src="'+matchingCategory[i].image+'" alt="'+matchingCategory[i].name+'" height="190"><h2>'+matchingCategory[i].name+'</h2><p>'+matchingCategory[i].info1+'</p><p>'+matchingCategory[i].info2+'</p><button onclick="categoryDetails('+matchingCategory[i].id+')">Book</button></div>';
    }
    $("#categoryList").html(strCategory);
}

displayCategories(categorySelected);


categoryBinding(objCategory)


