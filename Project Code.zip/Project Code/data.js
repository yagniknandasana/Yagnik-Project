var venuesCategory =[{
            "id":1,
            "image":"venues1.png",
            "name":"Ramada Hotel",
            "info1":"Vastrapur, Ahmedabad",
            "info2":"Banquet Halls, Lawns / Farmhouses",
            "review":"19 reviews"
        },{
            "id":2,
            "image":"venues2.png",
            "name":"MB Garden & Resorts",
            "info1":"Lucknow",
            "info2":"4 Star Wedding Hotels, Banquet Halls",
            "review":"10 reviews"
        },{
            "id":3,
            "image":"venues3.png",
            "name":"Rajhans Greens",
            "info1":"Kanakapura Road, Bangalore",
            "info2":"Banquet Halls, Lawns / Farmhouses",
            "review":"5 reviews"
        },{
            "id":4,
            "image":"venues4.png",
            "name":"Le Roma Gardenia",
            "info1":"North Bangalore, Bangalore",
            "info2":"3 Star Wedding Hotels, Lawns / Farmhouses",
            "review":"25 reviews"
        }];

var photographersCategory =[{
            "id":1,
            "image":"photographers1.png",
            "name":"Panchal Photography",
            "info1":"Talod",
            "info2":"<b>Rs 40,000  per day </b> (Photo + Video)",
            "review":"15 reviews"
        },{
            "id":2,
            "image":"photographers2.png",
            "name":"Abhi for Weddings",
            "info1":"Himmatnagar",
            "info2":"<b>35,000 Rs per day </b> (Photo + Video)",
            "review":"10 reviews"
        },{
            "id":3,
            "image":"photographers3.png",
            "name":"Popnock Photography",
            "info1":"Ahmedabad",
            "info2":"<b>25,000 Rs per day </b> (Photo + Video)",
            "review":"35 reviews"
        },{
            "id":4,
            "image":"photographers4.png",
            "name":"Pavan Soni Photography",
            "info1":"Gandhinagar",
            "info2":"<b>50,000 Rs per day </b> (Photo + Video)",
            "review":"55 reviews"
        }];

var planningCategory =[{
            "id":1,
            "image":"planning1.png",
            "name":"Save The Date",
            "info1":"Ahmedabad",
            "info2":"<b>< 1.5 Lac </b> (Planning Fee)",
            "review":"21 reviews"
        },{
            "id":2,
            "image":"planning2.png",
            "name":"MP Event & Entertainment",
            "info1":"Lucknow",
            "info2":"<b>< 2.5 Lac </b> (Planning Fee)",
            "review":"19 reviews"
        },{
            "id":3,
            "image":"planning3.png",
            "name":"The Select",
            "info1":"Bangalore",
            "info2":"<b>< 4.5 Lac </b> (Planning Fee)",
            "review":"34 reviews"
        },{
            "id":4,
            "image":"planning4.png",
            "name":"RJ Event Studio",
            "info1":"Chennai",
            "info2":"<b>< 6.5 Lac </b> (Planning Fee)",
            "review":"45 reviews"
        }];

var pre_wedding_shootCategory =[{
            "id":1,
            "image":"pre_wedding_shoot1.png",
            "name":"Land Of Love",
            "info1":"Hyderabad",
            "info2":"<b>On Request</b>",
            "review":"41 reviews"
        },{
            "id":2,
            "image":"pre_wedding_shoot2.png",
            "name":"The Shire Studio",
            "info1":"Mumbai",
            "info2":"<b>On Request</b>",
            "review":"75 reviews"
        },{
            "id":3,
            "image":"pre_wedding_shoot3.png",
            "name":"Destino",
            "info1":"Ahmedabad",
            "info2":"<b>On Request</b>",
            "review":"35 reviews"
        },{
            "id":4,
            "image":"pre_wedding_shoot4.png",
            "name":"HoneyBook Studios",
            "info1":"Delhi",
            "info2":"<b>On Request</b>",
            "review":"10 reviews"
        }];