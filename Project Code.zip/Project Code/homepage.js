function book(categorySelected){
    localStorage.setItem("categorySelected", categorySelected);
    window.location.href="category.html";
}