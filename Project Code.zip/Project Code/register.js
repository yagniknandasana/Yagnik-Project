let regName = /^[ A-za-z]{2,100}$/;
let regEmail = /^[A-Za-z0-9]{3,100}@gmail\.com$/;
let regPassword = /^[A-Za-z]{3,8}[!@#$%^&*]{1,}[0-9]{1,}$/;
let regMobileNo = /^[0-9]{10}$/;
let regAddress = /^[A-Za-z0-9 ,\n]{10,500}$/;

function register(){
    let name = document.querySelector("#name");
    let email = document.querySelector("#email");
    let pass = document.querySelector("#password");
    let confPass = document.querySelector("#confirmPassword");
    let mobileNo = document.querySelector("#mobile");
    let address = document.querySelector("#address");

    let ind1 = document.querySelector("#invalid1");
    let ind2 = document.querySelector("#invalid2");
    let ind3 = document.querySelector("#invalid3");
    let ind4 = document.querySelector("#invalid4");
    let ind5 = document.querySelector("#invalid5");
    let ind6 = document.querySelector("#invalid6");
    let ind7 = document.querySelector("#invalid7");
    
    //let isValid = true;
    let x = 0;
    
    if(regName.test(name.value)) {
        name.style.border="2px solid black";
        ind1.style.display="none"; 
        x++; 
    } else {
        isValid = false; 
        name.style.border="2px solid red";
        ind1.style.display="block";
    }

    if(regEmail.test(email.value)) {
        email.style.border="2px solid black";
        ind2.style.display="none"; 
        x++; 
    } else {
        isValid = false; 
        email.style.border="2px solid red";
        ind2.style.display="block"; 
    }

    if(regPassword.test(pass.value)) {
        pass.style.border="2px solid black";
        ind3.style.display="none"; 
        x++; 
    } else {
        isValid = false; 
        pass.style.border="2px solid red";
        ind3.style.display="block"; 
    }

    if(confPass.value==pass.value &&  confPass.value!="" && regPassword.test(confPass.value)) {   
        confPass.style.border="2px solid black";
        ind4.style.display="none"; 
        x++; 
    } else {
        isValid = false; 
        confPass.style.border="2px solid red";
        ind4.style.display="block"; 
    }

    if(regMobileNo.test(mobileNo.value)) {
        mobileNo.style.border="2px solid black";
        ind5.style.display="none"; 
        x++; 
    } else {
        isValid = false; 
        mobileNo.style.border="2px solid red";
        ind5.style.display="block"; 
    }

    if(document.querySelector('input[name="gender"]:checked') != null) {
        ind6.style.display="none"; 
        x++; 
    } else {
        isValid = false; 
        ind6.style.display="block"; 
    }

    if(regAddress.test(address.value)) {
        address.style.border="2px solid black";
        ind7.style.display="none"; 
        x++; 
    } else {
        isValid = false; 
        address.style.border="2px solid red";
        ind7.style.display="block"; 
    }
    
    if(x==7) {//isValid
        alert("Registered Successfully.");
        let userDetails ={
            name : name.value,
            email :email.value,
            pass :pass.value,
            mobileNo : mobileNo.value,
            gender:document.querySelector('input[name="gender"]:checked').value,
            address : address.value
        };
        window.localStorage.setItem('userDetails', userDetails);
        return true;
    } else {
        return false;
    }
}